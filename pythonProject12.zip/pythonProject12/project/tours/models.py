from django.db import models

class Tours(models.Model):
    name = models.CharField(max_length=20)
    country = models.CharField(max_length=20)
    hotel = models.CharField(max_length=20)
    people = models.IntegerField()
    costs = models.IntegerField()
    list_ex = models.CharField(max_length=20, choices=((1, 'ex1'),(2, 'ex2'),(3, 'ex3')))

    def __str__(self):
        return self.name

class Countries(models.Model):
    coname = models.CharField(max_length=20)

    def __str__(self):
        return self.name