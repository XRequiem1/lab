from django import forms
class AddForm(forms.Form):
    name = forms.CharField(max_length=20)
    country = forms.CharField(max_length=20)
    hotel = forms.CharField(max_length=20)
    people = forms.IntegerField()
    costs = forms.IntegerField()
    list_ex = forms.ChoiceField(choices=((1, 'ex1'), (2, 'ex2'), (3, 'ex3')))

class Countries(forms.Form):
    coname = forms.CharField(max_length=20)








