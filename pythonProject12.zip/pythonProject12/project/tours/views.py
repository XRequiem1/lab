from django.shortcuts import render, redirect
from .models import Tours, Countries
from .forms import AddForm

# Create your views here.

def index(request):
    makeTours()
    tour = Tours.objects.all()
    print(tour)
    return render(request, 'index.html', context={'tour': tour})

def delete(request, id):
    try:
        m = Tours.objects.get(id=id)
        m.delete()
        return redirect('home')
    except:
        return redirect('create')

def create(request):
    if request.method == 'POST':
        form = AddForm(request.POST)
        if form.is_valid():
            name = form.CharField(max_length=20)
            country = form.CharField(max_length=20)
            hotel = form.CharField(max_length=20)
            people = form.IntegerField()
            costs = form.IntegerField()
            list_ex = form.ChoiceField(choices=((1, 'ex1'), (2, 'ex2'), (3, 'ex3')))
            m, _ = Tours.objects.get_or_create(name=name, country=country, hotel=hotel, people=people,
                                               costs=costs, list_ex=list_ex)
            return redirect('home')
        else:
            form = AddForm()
            return render(request, 'create.html', context={'form': form})
    else:
        form = AddForm()
        return render(request, 'create.html', context={'form': form})

def update(request, id):
    try:
        men = Tours.objects.get(id=id)
        if request.method == 'POST':
            Tours.name = request.POST.get('name')
            Tours.country = request.POST.get('name')
            Tours.hotel = request.POST.get('name')
            Tours.people = request.POST.get('name')
            Tours.costs = request.POST.get('name')
            Tours.list_ex = request.POST.get('name')
            Tours.save()
            return redirect('home')
        else:
            return render(request, 'update.html', context={'Tours': Tours})

    except:
        return redirect('create')

def makeTours():
    p = Tours.objects.create(name='Tom1', country='Russia', hotel='sdsd', people=3, costs='34')
    p = Tours.objects.create(name='Tom2', country='China', hotel='sdsdsd', people=4, costs='15')
    p = Tours.objects.create(name='Tom3', country='USA', hotel='trivago', people=5, costs='14')
    p = Tours.objects.create(name='Tom4', country='India', hotel='mig', people=6, costs='13')
    p = Tours.objects.create(name='Tom5', country='Argentina', hotel='asasas', people=1, costs='12')

